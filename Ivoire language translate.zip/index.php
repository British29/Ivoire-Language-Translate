<?php session_start(); ?>



<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="style.css">
	<?php include 'lien.php' ?>
    <link rel="stylesheet" type="text/css" href="css/util.css">
    <link rel="stylesheet" type="text/css" href="css/main.css">

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
  <script src="https://kit.fontawesome.com/7cb0e7c261.js" crossorigin="anonymous"></script>
</head>
	<title> page de connexion </title>
</head>
<body>

<div class="limiter">
<div class="container-login100">
<div class="wrap-login100 p-t-50 p-b-100">
<h1><b><u> CONNECTEZ-VOUS </u> </b></h1><br><br>
    <p>
       <span style="color: rgb(255, 145, 77);" class="h1">Ivoire</span>
       <span style="color: rgb();" class="h1"> Language</span>
       <span style="color: rgb(12, 199, 12);" class="h1"> Translator</span>
   </p>
                    <br>
<div class="container-fluid">
    <div class="row">
                  

    <form id=""  method="POST" action="page.php">

      <div class="form-label-group">
          <h2 class="nu">Email</h2>
        <input type="text" name="email" id="email" class="form-control" placeholder="Entrer votre Email" required autofocus>
        
      </div><br>
          <div class="form-label-group">
          <h2 class="nu">Role</h2>
          <select class="form-control"placeholder="Choississez un role"required autofocus >
          <option value="" >Définir votre role</option>
          <option value="Superviseur">Superviseur</option>
          <option value="Administrateur">Administrateur</option>
          <option value="Opérateur de saisie">Operateur</option>
          </select>
          </div><br>
      <div class="form-label-group">
          <h2 class="nu">Mot de Passe</h2>
        <input type="password" name="password" id="password" class="form-control" placeholder="Password" required>
        
      </div><br>

      
     <button class="btn btn-lg btn-primary btn-block" type="Submit" name="connexion">Connexion</button>
      <p class="mt-5 mb-3 text-muted text-center"><a href="Mot de passe oublié?">Mot de passe oublié?</a></p>
    </form>

</div>
</div>
</div>
</div>
</div>




<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "traduction";
$conn = new mysqli($servername, $username, $password, $dbname);


if(isset($_POST['connexion'])){
$email = $_POST['email'];
$password = md5($_POST['password']);


$sql = "SELECT * FROM user WHERE email = '$email' AND password = '$password' ";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
  
$row = mysqli_fetch_assoc($result);
  $nom = $row["nom"];
  $role = $row["role"];
   $_SESSION['nom'] = $nom;
   $_SESSION['role'] = $role;

   header("Location: page.php");
  
    } else {
      // echo "Error: " . $sql . "<br>" . mysqli_error($con);
      echo " Email ou mot de passe incorrect " ;
    }

    }


    mysqli_close($conn);

    ?> 

</body>
</html>