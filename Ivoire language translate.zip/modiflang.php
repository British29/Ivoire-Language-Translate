<?php session_start();
?>

<?php


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "traduction";
$conn = new mysqli($servername, $username, $password, $dbname);

if (isset($_GET['id'])){

$id = $_GET['id'];
$query = "SELECT * FROM tlangue_start WHERE id = $id";
$result = mysqli_query($conn, $query);
if (mysqli_num_rows($result) == 1) {
	$row = mysqli_fetch_array($result);
    $langue = $row['langue'];
	$date_enreg = date("Y-m-d ");
}
 
}

if (isset($_POST['Modifier'])){
    $id = $_GET['id'];
    $langue = $_POST['langue'];
	$date = date("Y-m-d ");

	$query = "UPDATE tlangue_start SET langue = '$langue', date_enreg = '$date_enreg' WHERE id = $id";
	mysqli_query($conn, $query);
	header("Location: page.php");

}
?>


<!DOCTYPE html>
<html>
    <head>
        <title>Modifier une langue</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
          <?php include 'lien.php' ?>

    </head>
    <body>
        <div class="container center-div">
        
            <div class="container row d-flex flex-row justify-content-center mb-8">
                <div class="admin-form shadow p-5">

                    <form id="myForm" action="modiflang.php?id=<?php echo $_GET['id']; ?>" method="POST">

                    <center><h3>Modifier une langue</h3></center><br>
                    <div class="row">
                        <div class="col form-group">
                        <label class="font-weight-bold">Langue</label>
                        <input type="text" value="<?php echo $langue; ?>" class="form-control" id="langue" placeholder="Modifier la langue" name="langue">
                        </div>
                    </div>
                    <input type="submit" name= "Modifier" class="btn bg-primary text-dark" id="Modifier" value="Modifier">
                    </form>

                </div> 
            </div>

        </div>
    </body>
</html>
