<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "traduction";
$conn = new mysqli($servername, $username, $password, $dbname);

 	if (isset($_GET['id'])) {
 		$id = $_GET['id'];
 		$query = "DELETE FROM data WHERE id = $id";
 		$result = mysqli_query($conn, $query);

 		if (!$result) {
 			die("Failed");
 		}
 		
 		header("location: page.php");

 	}
 ?>