<?php session_start(); ?>
<?php 


    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "traduction";
    $conn = new mysqli($servername, $username, $password, $dbname);

 ?>

<!DOCTYPE html>
<html>
<head>
    <title>Traduction</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <?php include('lien.php');?>
</head>
<body class="">

<div class="container center-div">
	  
      <div class="container row d-flex flex-row justify-content-center mb-8">
	    <div class="admin-form shadow p-4">
    <style>

    </style>
    <header>
        <center> <h3 class="text-success"><a href="pageUtilisateur.php"> IVOIRE LANGUAGE TRANSLATOR </a></h3>
        <a href="#"><img src="ILT.PNG" alt="logo" height="160" width="160"></a>
        </center>
    </header>
    <main class="">

        <div class="container center-block">
        <br>
        <div class="form-group">
        <form action="" method="POST" enctype="multipart/form-data">

          <select class="form-control" name ="langue_start" id ="langue_start">
          <option value="" class="" > Sélectionner une langue </option>
            <?php
              $sql = "SELECT * FROM tlangue_start";
              $result = mysqli_query($conn, $sql);
              while ($row = mysqli_fetch_array($result)) {
                echo '<option>'.$row['langue'].'</option>';
              }
            ?> 
          </select>
         <br> 
        <textarea name="champ1" id="champ1" cols="35" rows="5"></textarea>
        </div>

        <div class="form-group">
          <select class="form-control" name ="langue_end" id ="langue_end">
          <option value="" class="" > Sélectionner une langue </option>
            <?php
              $sql = "SELECT * FROM tlangue_start";
              $result = mysqli_query($conn, $sql);
              while ($row = mysqli_fetch_array($result)) {
                echo '<option>'.$row['langue'].'</option>';
              }
            ?> 
          </select>
        
        <input type="submit" value="Traduire" name="Traduire" class="btn btn-warning">
          </form>
        </div>
        </div>
        
        
        </div>
    </main>

    <div class="form-group">

    <?php 

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "traduction";
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    if (isset($_POST['Traduire'])) {

        $search_text = $_POST['champ1'];
        $langue_start = $_POST['langue_start'];
        $langue_end = $_POST['langue_end'];
        $ip = $_SERVER['REMOTE_ADDR'];

        $date_enreg = date("Y-m-d ");
        $sql = "INSERT INTO recherche (search_text, langue_start, langue_end, ip, date) VALUES ('$search_text','$langue_start','$langue_end', '$ip', '$date_enreg')";
    
        if (mysqli_query($conn, $sql)) {

          $query = "SELECT * FROM data WHERE texte1 = '$search_text' AND langue_start = '$langue_start' AND langue_end = '$langue_end' ";
            $result = mysqli_query($conn, $query);
            


            while($row = mysqli_fetch_array($result)) { ?>

              <div class="container center-div">
              
              <div class="container row d-flex flex-row justify-content-center mb-8">
              <div class="admin-form shadow p-4">
              <table class="table table-bordered">
                <br><br><br><br><br><br><br><br><br><br>
              <tr>
              <td> <?php echo $row['texte2']?> </td>
              <br>
              <td>
                <audio controls>
                  <source src="<?php echo $row['audio'] ?>" type="audio/mpeg">
                </audio>
              </td>
              </tr>
              </table><br>

              <br><br><br>
              </div>
              </div>
              </div>
              <?php } ?>

              <?php    
          }
    }else{
      echo '';
    }
    mysqli_close($conn);
    
    ?>

</div>
  </div>
  </div>

</div>
</div>
</div>
</body>
</html>