<?php session_start();
?>

<!DOCTYPE html> 
<html lang="en">
<head>

	<title></title>
	 <meta charset="utf-8">
     <meta name="viewport" content="width=device-width, initial-scale=1">
	 <link rel="stylesheet" type="text/css" href="style.css">
   <link rel="stylesheet" type="text/css" href="css/util.css">
    <link rel="stylesheet" type="text/css" href="css/main.css">

	 <?php include 'lien.php' ?>

</head>
<body>

<header>
	  <div class="container center-div shadow">
	  <div class="text-uppercase mb-5">
		
	  </div>
      <div class="container row d-flex flex-row justify-content-center mb-8">
	  <div class="admin-form shadow p-5">


        <form id="myform" action="" method="post">


       
          <center><h3> ENREGISTRER UN UTILISATEUR </h3></center><br>
          
          <div class="form-group">
          <label>Nom & Prenoms:</label>
          <input type="text" class="form-control" id="nom" placeholder="Saisir le nom et Prenoms" name="nom" required>
          </div>



          <div class="form-group">
          <label>Email:</label>
          <input type="email" class="form-control" id="email" placeholder="Entrer l'email" name="email" required>
          </div>

          <div class="form-group">
          <label>Mot de pass:</label>
          <input type="password" class="form-control" id="pwd" placeholder="Entrer le mot de pass" name="pwd" required>
          </div>

          <div class="form-group">
          <label>Role:</label>
          <select class="form-control" name = "role" id = "role" required>
	      <option value = "">Choississez un role</option>
	      <option value = "Administrateur">Administrateur</option>
	      <option value = "Operateur">Operateur</option>
        <option value = "Superviseur">Superviseur</option>
          </select>	  
          </div>

       <center><button type="submit" name = "Enregistrer" class="btn bg-primary">Enregistrer</button></center>


     </form>

   </div>
   </div> 
   </div>

  </header>

<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "traduction";
$conn = new mysqli($servername, $username, $password, $dbname);


if(isset($_POST['Enregistrer'])){
$nom = $_POST['nom'];
$role = $_POST['role'];
$email = $_POST['email'];
$password = md5($_POST['password']);
$date_enreg = date("d-m-Y");

$sql = "INSERT INTO user (nom, role, email, password, date_enreg) VALUES ('$nom', '$role', '$email','$password','$date_enreg')";

if (mysqli_query($conn, $sql)) {

 
    echo '<script language="Javascript">';
    echo 'document.location.replace("./page.php")';
    echo ' </script>';

} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

}else{
	echo "";
}


mysqli_close($conn);

?>

</body>
</html>