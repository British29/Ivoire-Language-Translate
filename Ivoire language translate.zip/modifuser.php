<?php session_start(); ?>
<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "traduction";
$conn = new mysqli($servername, $username, $password, $dbname);


if (isset($_GET['id'])){

$id = $_GET['id'];
$query = "SELECT * FROM user WHERE id = $id";
$result = mysqli_query($conn, $query);
if (mysqli_num_rows($result) == 1) {
	$row = mysqli_fetch_array($result);
    $nom = $row['nom'];
    $email = $row['email'];
    $password = md5($row['password']);
    $role = $row['role'];
	$date_enreg = date("Y-m-d ");
}
 
}

if (isset($_POST['Modifier'])){
    $id = $_GET['id'];
    $nom = $_POST['nom'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $role = $_POST['role'];
	$date_enreg = date ("Y-m-d");

	$query = "UPDATE user SET nom = '$nom', email = '$email', password = '$password', role = '$role', date = '$date_enreg' WHERE id = $id";
	mysqli_query($conn, $query);
    header("Location: page.php");

}
?>


<!DOCTYPE html>
<html>
    <head>
        <title>Modifier un texte</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
       <?php include('lien.php');?>
 
    <body>
    <div class="container center-div">
	  
      <div class="container row d-flex flex-row justify-content-center mb-8">
	    <div class="admin-form shadow p-5">


        <form id="myForm" action="modifuser.php?id=<?php echo $_GET['id']; ?>" method="POST">

          <center><h3>Modifier un utilisateur</h3></center><br>
          <div class="col form-group">
                            <label class="font-weight-bold">Nom et Prénom</label>
                            <input type="name" value="<?php echo $nom; ?>" class="form-control" id="nom" placeholder="Saisir nom et prénom" name="nom" required>
                        </div>
                        <div class="col form-group">
                            <label class="font-weight-bold">Email</label>
                            <input type="email" value="<?php echo $email; ?>" class="form-control" id="email" placeholder="Saisir email" name="email" required>
                        </div>
                        <div class="col form-group">
                            <label class="font-weight-bold">Role</label>
                            <select name="role" id="role" required>
                                <option value="">Modifier le role</option>
                                <option value="Opérateur de saisie">Operateur</option>
                                <option value="Administrateur">Administrateur</option>
                                <option value="Superviseur">Superviseur</option>
                            </select>
                        </div>
       <input type="submit" name= "Modifier" class="btn bg-primary text-dark" id="Modifier" value="Modifier">
     </form>
   </div>
   </div> 
   </div>

  </div>
 
</body>
</html>

