-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  mer. 08 juil. 2020 à 15:40
-- Version du serveur :  10.1.37-MariaDB
-- Version de PHP :  7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `traduction`
--

-- --------------------------------------------------------

--
-- Structure de la table `activite`
--

CREATE TABLE `activite` (
  `id` int(11) NOT NULL,
  `id_user` varchar(50) NOT NULL,
  `action` text NOT NULL,
  `Date_enreg` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `activite`
--

INSERT INTO `activite` (`id`, `id_user`, `action`, `Date_enreg`) VALUES
(0, '194.560.1', 'Propositon de mot en baoule', '2020-07-07'),
(1, '194.560.1', 'Ajouter un nouveau en Abron', '2020-07-07');

-- --------------------------------------------------------

--
-- Structure de la table `data`
--

CREATE TABLE `data` (
  `id` int(11) NOT NULL,
  `texte1` text NOT NULL,
  `langue_start` varchar(50) NOT NULL,
  `texte2` text NOT NULL,
  `langue_end` varchar(11) NOT NULL,
  `audio` varchar(30) NOT NULL,
  `date_enreg` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `data`
--

INSERT INTO `data` (`id`, `texte1`, `langue_start`, `texte2`, `langue_end`, `audio`, `date_enreg`) VALUES
(0, 'Bonjour', 'Francais', 'Anisongoman', 'Dioula', '', '2020-07-07 '),
(1, 'Je m\'appelle', 'Francais', 'itogo bedi', 'Dioula', '', '2020-07-07 '),
(2, 'Comment tu vas ?', 'Francais', 'Abedi', 'Dioula', '', '2020-07-07 ');

-- --------------------------------------------------------

--
-- Structure de la table `recherche`
--

CREATE TABLE `recherche` (
  `id` int(11) NOT NULL,
  `search_text` text NOT NULL,
  `langue_start` varchar(50) NOT NULL,
  `langue_end` varchar(50) NOT NULL,
  `ip` varchar(40) NOT NULL,
  `Date_enreg` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `recherche`
--

INSERT INTO `recherche` (`id`, `search_text`, `langue_start`, `langue_end`, `ip`, `Date_enreg`) VALUES
(0, 'Bonjour', 'Francais', 'Dioula', '192.456.100.2', '2020-07-07'),
(1, 'je m\'appelle', 'Francais', 'Dioula', '192.465.67.2', '2020-07-07');

-- --------------------------------------------------------

--
-- Structure de la table `tlangue_end`
--

CREATE TABLE `tlangue_end` (
  `id` int(11) NOT NULL,
  `langue` varchar(50) NOT NULL,
  `date_enreg` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `tlangue_end`
--

INSERT INTO `tlangue_end` (`id`, `langue`, `date_enreg`) VALUES
(0, 'Baoule', '09/10/2019'),
(1, 'Gouro', '09/10/2019'),
(2, 'Senoufo', '09/10/2019');

-- --------------------------------------------------------

--
-- Structure de la table `tlangue_start`
--

CREATE TABLE `tlangue_start` (
  `id` int(11) NOT NULL,
  `langue` varchar(50) NOT NULL,
  `date_enreg` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `tlangue_start`
--

INSERT INTO `tlangue_start` (`id`, `langue`, `date_enreg`) VALUES
(0, 'Gouro', '2020-07-07 '),
(1, 'Anglais', '2020-07-07 '),
(2, 'Dioula', '2020-07-07 '),
(3, 'Francais', '2020-07-07 '),
(4, 'Baoule', '2020-07-07 ');

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `nom` varchar(50) NOT NULL,
  `role` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(40) NOT NULL,
  `date_enreg` varchar(14) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `user`
--

INSERT INTO `user` (`id`, `nom`, `role`, `email`, `password`, `date_enreg`) VALUES
(0, 'Odilon dje bi', 'Administrateur', 'odilondjebi@gmail.com', 'b5b03f06271f8917685d14cea7c6c50a', '2020-07-07 '),
(1, 'Herve', 'Operateur', 'Herve@gmail.com', 'cdaeb1282d614772beb1e74c192bebda ', '2020-07-07 '),
(2, 'Ruth chichi', 'superviseur', 'Ruth@gmail.com', 'cdaeb1282d614772beb1e74c192bebda ', '2020-07-07 '),
(3, 'Junior ', 'Superviseur', 'Junior@gmail.com', 'b5b03f06271f8917685d14cea7c6c50a', '2020-07-07 ');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `activite`
--
ALTER TABLE `activite`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `data`
--
ALTER TABLE `data`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `recherche`
--
ALTER TABLE `recherche`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `tlangue_end`
--
ALTER TABLE `tlangue_end`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `tlangue_start`
--
ALTER TABLE `tlangue_start`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
